﻿
namespace PokerRoomManager
{
    public class Room
    {
        public string Name { get; set; }
        public int Port { get; set; }
        public int Pid { get; set; }
    }
}